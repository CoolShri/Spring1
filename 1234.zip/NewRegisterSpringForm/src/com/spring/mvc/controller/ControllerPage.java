package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.mvc.model.Employee;
import com.spring.mvc.service.EmployeeService;
import com.spring.mvc.service.IEmployeeService;

@Controller
public class ControllerPage 
{
	@Autowired
	IEmployeeService empSer;
	
	@RequestMapping("/HomePage")
	public String showHomePage()
	{
		String view="HomePage";
		return view;
	}

	@RequestMapping("/reg")
	public String registrationPage(Model model,HttpServletRequest request)
	{
		String view="registerPage";
		model.addAttribute("msg","Welcome To Registration Page");
		model.addAttribute("employee",new Employee());
		List<String> list=new ArrayList<>();
		list.add("Noida");
		list.add("Ghaziabad");
		list.add("Saharanpur");
		list.add("Meerut");
		list.add("Moradabad");
		ServletContext context=request.getServletContext();
		context.setAttribute("cities", list);
		//model.addAttribute("cities",list);
		List<String> list2=new ArrayList<>();
		list2.add("male");
		list2.add("female");
		list2.add("others");
		ServletContext context1=request.getServletContext();
		context1.setAttribute("numberList", list2);
		//model.addAttribute("numberList",list2);
		return view;
	}
	
	
	@RequestMapping(value="/registerPage",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
	if(bindingResult.hasErrors())
	{
		view="registerPage";
		return view;
	}
	else
	{
		empSer.insertEmployee(emp);
		ServletContext context=req.getServletContext();
		context.setAttribute("employee", emp);
		//model.addAttribute("employee",emp);
		view="successPage";
		return view;
		
	}
	}
	
	@RequestMapping("/update")
	public String updateUser(Model model,HttpServletRequest request)
	{
		model.addAttribute("employee",new Employee());
		String view="updatePage";
		model.addAttribute("msg","Welcome To Updation Page");
		return view;
	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String validateUpdatePage(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
	if(bindingResult.hasErrors())
	{
		view="updatePage";
		return view;
	}
	else
	{
		empSer.updateEmployee(emp.getEmpId());
		ServletContext context=req.getServletContext();
		context.setAttribute("employee", emp);
		//model.addAttribute("employee",emp);
		view="employeeDataPage";
		return view;
		
	}
	}
	
	
}
