package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.Employee;

public interface IEmployeeService {
	void insertEmployee(Employee emp);
	List<Employee> getAllEmployees(int id);
	Employee updateEmployee(int id);
}
