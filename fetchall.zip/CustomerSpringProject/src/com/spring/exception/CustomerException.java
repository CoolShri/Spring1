package com.spring.exception;

public class CustomerException extends Exception
{

	public CustomerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
