package com.spring.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.model.Customer;

@Repository
public class CustomerDAOImpl implements CustomerDAO 
{
	@PersistenceContext
	EntityManager manager;

	@Override
	public List<Customer> getAll() 
	{
		Query query = manager.createQuery(" from Customer ",Customer.class);
		List<Customer> list = query.getResultList();
		return list;
	}

}
