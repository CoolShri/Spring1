package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.model.Student;

@Repository
public class StudentDao implements IStudentDao {
      		
	@PersistenceContext
	private EntityManager manager;
	@Override
	public void insert(Student stu)
	{
		
		manager.persist(stu);
	}
	@Override
	public List<Student> getAllStudent() {
		Query query = manager.createQuery("select stu from Student stu");
		List<Student> list = query.getResultList();
		return list;
	}

}
