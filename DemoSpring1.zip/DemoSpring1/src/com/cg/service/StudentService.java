package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IStudentDao;
import com.cg.model.Student;

@Service
@Transactional
public class StudentService implements IStudentService {

	@Autowired
	IStudentDao sdao;
	@Override
	public void insert(Student stu) 
	{
		sdao.insert(stu);
	}
	@Override
	public List<Student> getAllStudent() 
	{
		
		return sdao.getAllStudent();
	}

}
