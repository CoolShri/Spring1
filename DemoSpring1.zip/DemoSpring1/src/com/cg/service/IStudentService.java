package com.cg.service;

import java.util.List;

import com.cg.model.Student;

public interface IStudentService 
{
public void insert(Student stu);
public List<Student> getAllStudent();

}
