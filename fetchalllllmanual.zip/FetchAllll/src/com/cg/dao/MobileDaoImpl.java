package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.annotation.Persistent;
import org.springframework.stereotype.Repository;

import com.cg.model.Mobile;

@Repository
public class MobileDaoImpl  implements MobileDao
{

	@PersistenceContext
	EntityManager manager;
	@Override
	public List<Mobile> getAll() 
	{
	
		Query q=manager.createQuery("from Mobile");
		List<Mobile>list=new ArrayList<Mobile>();
		list=q.getResultList();
		return list;
	}
	

}
