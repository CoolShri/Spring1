package com.cg.dao;

import java.util.List;

import com.cg.model.Mobile;

public interface MobileDao 

{
	List<Mobile>getAll();

}
