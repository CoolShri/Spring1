package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Mobile 
{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int mid;
	String mobileName;
	public Mobile()
	{
		super();
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	@Override
	public String toString() {
		return "Mobile [mid=" + mid + ", mobileName=" + mobileName + "]";
	}
	public Mobile(int mid, String mobileName) {
		super();
		this.mid = mid;
		this.mobileName = mobileName;
	}
	
}
