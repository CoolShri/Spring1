package com.cg.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.model.Mobile;
import com.cg.service.IMobileService;

@Controller
public class controllerMy 
{

	@Autowired
	IMobileService mSer;
	
	@RequestMapping(value="/HomePage")
	public String homepage()
	{
		String view="Homepage";
		return view;
	}
	@RequestMapping(value="/show")
	public String all(Model model, HttpServletRequest request)
	{

		List<Mobile>mobileList=mSer.getAll();
		 ServletContext context=request.getServletContext();
			context.setAttribute("mobile",mobileList);
			String view="display";
			return view;
		
	}
	
	
}
