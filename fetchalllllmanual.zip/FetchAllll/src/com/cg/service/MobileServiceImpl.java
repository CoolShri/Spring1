package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.MobileDao;
import com.cg.model.Mobile;

@Service
@Transactional
public class MobileServiceImpl implements IMobileService
{
	@Autowired
	MobileDao mDao;

	@Override
	public List<Mobile> getAll() {
		return mDao.getAll();
	}

}
