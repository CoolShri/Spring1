package com.spring.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ControllerPage 
{
@RequestMapping("/")
public String doProcess()
{
	String view="HomePage";
	return view;
}
@RequestMapping(value="/reg", method=RequestMethod.GET)
public String regpage(Model model)
{
	String view="Register";
	model.addAttribute("msg","Welcome To Registration Page");
	return view;
}
@RequestMapping(value="/reg", method=RequestMethod.POST)
public String showRegPage(@Model model)
{
	String view="Register";
	model.addAttribute("msg","Welcome To Registration Page");
	return view;
}
	
}
