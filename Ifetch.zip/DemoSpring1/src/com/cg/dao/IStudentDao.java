package com.cg.dao;

import java.util.List;

import com.cg.model.Student;

public interface IStudentDao 
{
	public void insert(Student stu);
	public List<Student> getAllStudent();

}
