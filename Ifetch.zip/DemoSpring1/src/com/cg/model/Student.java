package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Student 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int id;
	
	@NotEmpty(message="Name can not be empty")
	@Size(min=3,max=10,message="Name should be in limits")
    String name;
	
	@NotEmpty(message="City can not be empty")
	@Size(min=3,max=10,message="Name should be in limits")
    String city;
	
	@NotEmpty(message="Gender can not be empty")
	@Size(min=3,max=10,message="Name should be in limits")
    String gender;
	
	@NotNull(message="Age can not be empty")
	@Min(value=16)
	int age;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", city=" + city + ", gender=" + gender + ", age=" + age + "]";
	}

	public Student(int id, String name, String city, String gender, int age) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.gender = gender;
		this.age = age;
	}

	public Student() {
		super();
	}
	
}
