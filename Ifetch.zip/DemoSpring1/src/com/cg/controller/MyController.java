package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.model.Student;
import com.cg.service.IStudentService;

@Controller
public class MyController
{
	@Autowired
	IStudentService stuser;
	@RequestMapping("/homepage")
	public String showHomePage()
	{
		String view="Homepage1";
		return view;
	}
	
	@RequestMapping("/reg")
	public String showRegister(Model model,HttpServletRequest request)
	{
		String view="Register";
		List<String> list=new ArrayList<>();
		list.add("Noida");
		list.add("Ghaziabad");
		list.add("Saharanpur");
		list.add("Meerut");
		list.add("Moradabad");
		ServletContext context=request.getServletContext();
		context.setAttribute("city", list);
		
		
		List<String> list2=new ArrayList<>();
		list2.add("male");
		list2.add("female");
		list2.add("others");
		ServletContext context1=request.getServletContext();
		context1.setAttribute("gender", list2);
		model.addAttribute("student",new Student());
		return view;
	}
	
	
	@RequestMapping(value="/RegisterProcess",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid @ModelAttribute("student") Student stu ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
	if(bindingResult.hasErrors())
	{
		view="Register";
		return view;
	}
	else
	{
		stuser.insert(stu);
		ServletContext context=req.getServletContext();
		context.setAttribute("student", stu);
		view="Success";
		return view;
		
	}
	
	
	
	}

	@RequestMapping(value="/getall")
	public String GetAllData(Model model ,HttpServletRequest req)
	{
		List<Student> li=new ArrayList<Student>();
        li=stuser.getAllStudent();
        
        ServletContext context4=req.getServletContext();
        context4.setAttribute("details", li);
    String view="Display";
    
    return view;
    
	}
	
	
	
	
}
