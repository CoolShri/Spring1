package com.spring.mvc.dao;

import com.spring.mvc.model.QueryMaster;
//interface for dao 
public interface IGearDao 
{
	public QueryMaster searchById(int id);
	public void add(QueryMaster query1);
}
