package com.spring.mvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.QueryMaster;
//to specify that it is a dao class
@Repository
public class GearDaoImpl implements IGearDao
{
	//to create the object of entitymanager object
	@PersistenceContext
	EntityManager entitymanager;
	//to search by id
	@Override
	public QueryMaster searchById(int id) {
		QueryMaster querym=entitymanager.find(QueryMaster.class,id);
		return querym;
	}
	//to update the data in the database
	@Override
	public void add(QueryMaster query) {
		
	
	QueryMaster qr=entitymanager.find(QueryMaster.class,query.getQueryId());
	qr.setSolutions(query.getSolutions());
	qr.setSolutionGivenBy(query.getSolutionGivenBy());
	entitymanager.persist(qr);
	}


}
