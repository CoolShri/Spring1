package com.spring.mvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
//to create the table in database
@Entity
//to change the table name
@Table(name="query_master")
public class QueryMaster 
{
	//to make queryId primary key
	@Id
	//to autogenerate id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//to change column name
	@Column(name="query_id")
	private int queryId;
	//to specify that technology cannot be null
	@NotEmpty(message="It cannot be null")
	private String technology;
	@Column(name="query_raised_by")
	//it cannot be null
	@NotEmpty(message="It cannot be null")
	
	private String queryRaised;
	//it cannot be null
	@NotEmpty(message="It cannot be null")
	private String query;

	private String solutions;
	@Column(name="solutionby")
	
	private String solutionGivenBy;
	//Getters and setters
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaised() {
		return queryRaised;
	}
	public void setQueryRaised(String queryRaised) {
		this.queryRaised = queryRaised;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}
	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}
	//Default-Constructor
	public QueryMaster() {
		super();
	}
	
}
