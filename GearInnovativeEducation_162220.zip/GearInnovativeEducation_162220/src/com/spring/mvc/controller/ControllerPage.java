package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.spring.mvc.model.QueryMaster;
import com.spring.mvc.service.IGearService;
//annotation for controller
@Controller
public class ControllerPage 
{
	//To create object of Service class
	@Autowired
	IGearService gearSer;
	//to open the first page
	@RequestMapping("/SerachPage")
	public String doProcess(Model model)
	{
		String view="SerachPage";
		model.addAttribute("querySolutions",new QueryMaster());
		return view;
	}
	//to open the search page
	@RequestMapping(value="/queryanswer",method=RequestMethod.POST)
	public String createAccountPage(@Valid @ModelAttribute("querySolutions") QueryMaster querymaster,BindingResult bindingresult,HttpServletRequest request,Model model)
	{
		String view="";
		QueryMaster qm=gearSer.searchById(querymaster.getQueryId());
		if(qm!=null)
		{
		model.addAttribute("querySolutions",new QueryMaster());
		ServletContext context=request.getServletContext();
		context.setAttribute("q",qm);
		List<String> answeredBy=new ArrayList<>();
		answeredBy.add("Uma");
		answeredBy.add("Rahul");
		answeredBy.add("Kavita");
		answeredBy.add("Hema");
		ServletContext context1=request.getServletContext();
		context1.setAttribute("solutionname",answeredBy);
		view="QueryAnswer";
		}
		else
		{
			model.addAttribute("msg3","Query Not Found,wrong query id:"+querymaster.getQueryId());
			view="Failure";
		}
	return view;
		
	}
	//to enter the solution and solution name
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String updatepage(@ModelAttribute("querySolutions") QueryMaster querymaster,BindingResult bindingresult ,Model model,HttpServletRequest request)
	{
		String view="";
		gearSer.add(querymaster);
		ServletContext context=request.getServletContext();
		context.setAttribute("msg1","Solution for Query ID: "+querymaster.getQueryId()+" submitted successfully");
		view="Success";
		return view;
		
	}
	
	
}
