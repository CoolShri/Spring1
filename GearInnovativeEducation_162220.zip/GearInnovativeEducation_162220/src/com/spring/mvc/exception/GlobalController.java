package com.spring.mvc.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalController 
{
	@ExceptionHandler(Exception.class)
	public ModelAndView myException(Model model,Exception exception)
	{
		ModelAndView view=new ModelAndView("failure");
		view.addObject("msg3",exception.getMessage());
		return view;
	}
}
