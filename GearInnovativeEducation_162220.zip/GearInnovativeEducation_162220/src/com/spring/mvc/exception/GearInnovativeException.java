package com.spring.mvc.exception;

public class GearInnovativeException  extends Exception
{

	public GearInnovativeException() {
		super();
	
	}

	public GearInnovativeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	
	}

	public GearInnovativeException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public GearInnovativeException(String message) {
		super(message);
		
	}

	public GearInnovativeException(Throwable cause) {
		super(cause);
	}
	
}
