package com.spring.mvc.service;

import com.spring.mvc.model.QueryMaster;
//interface for service class
public interface IGearService 
{
	public QueryMaster searchById(int id);
	public void add(QueryMaster query1);
}
