package com.spring.mvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.dao.IGearDao;
import com.spring.mvc.model.QueryMaster;
//annotation to specify that it is a service class
@Service
@Transactional
public class GearServiceImpl  implements IGearService
{
	//to create object of dao class
	@Autowired
	IGearDao gearDao;
	//method to search by id
	@Override
	public QueryMaster searchById(int id) {
		
		return gearDao.searchById(id);
	}
	//method to update details in the database
	@Override
	public void add(QueryMaster query1) {
		gearDao.add(query1);
		
	}

}
