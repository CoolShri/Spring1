package com.spring.mvc.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalController {
	@ExceptionHandler(Exception.class)
public String empException(Model model,Exception excp)
{
	String view="error";
	model.addAttribute("err",excp.getMessage());
	return view;
}
}
