package com.spring.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.Employee;
@Repository
public class EmployeeDao implements IEmployeeDao {
	
	
    @PersistenceContext
	private EntityManager manager;
	
	@Override
	public void insertEmployee(Employee emp) {
		manager.persist(emp);
		
	}

	@Override
	public List<Employee> getAllEmployees(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee(int id) {
	     return manager.find(Employee.class, id);
	}

	@Override
	public void updatedEmployeeDetails(Employee emp) {
		manager.merge(emp);
		
	}

}
