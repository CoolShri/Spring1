package com.spring.mvc.dao;

import java.util.List;

import com.spring.mvc.model.Employee;

public interface IEmployeeDao {
void insertEmployee(Employee emp);
List<Employee> getAllEmployees(int id);
Employee updateEmployee(int id);
void updatedEmployeeDetails(Employee emp);
}
