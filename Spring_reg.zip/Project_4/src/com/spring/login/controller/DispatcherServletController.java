package com.spring.login.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.reg.controller.Employee;

@Controller
public class DispatcherServletController {
	
	@RequestMapping("/home")
	public String showHomePage() {
		String view="home";
		return view;
	}
	
	@RequestMapping("/register")
	public String showRegisterPage(Model model) {

		String view = "register";

		model.addAttribute("employee", new Employee());

		List<String> list = new ArrayList<>();
		list.add("Hyderabad");
		list.add("Chennai");
		list.add("Bangalore");
		list.add("Pune");

		model.addAttribute("cities", list);
		return view;
	}

@RequestMapping(value = "/register" , method = RequestMethod.POST)
public String processRegistration (@ModelAttribute("employee") 
Employee employee,Model model)
	{

		String view = "registerSuccess";
		model.addAttribute("emp", employee);
		return view;
	}
}
