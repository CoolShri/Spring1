package com.spring.reg.controller;

public class Employee {
public Employee() {
		
	}
String Name;
String designation;
double salary;
String city;

public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}


}
