package com.cg.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mvc.dao.IBookDao;
import com.cg.mvc.model.Book;
@Service
@Transactional
public class BookServiceImpl implements IBookService{

	@Autowired
	IBookDao dao;
	
	@Override
	public void insertBook(Book book) {
	
		dao.insertBook(book);
	}

	@Override
	public List<Book> getAllBooks() {
		
		return dao.getAllBooks();
	}

}
