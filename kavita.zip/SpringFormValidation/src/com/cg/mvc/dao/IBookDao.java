package com.cg.mvc.dao;

import java.util.List;

import com.cg.mvc.model.Book;

public interface IBookDao {

	void insertBook(Book book);
	
	List<Book> getAllBooks();
	
}
