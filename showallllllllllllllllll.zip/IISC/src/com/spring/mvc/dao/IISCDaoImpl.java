package com.spring.mvc.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.IIT;
@Repository
public class IISCDaoImpl implements IISCDao {

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public List<IIT> all() 
	{
		Query q=manager.createQuery("from IIT");
		List<IIT>list=new ArrayList<IIT>();
		list=q.getResultList();
		
		return list;
	}

}
