package com.spring.mvc.dao;

import java.util.List;

import com.spring.mvc.model.IIT;

public interface IISCDao
{
	List<IIT>all();

}
