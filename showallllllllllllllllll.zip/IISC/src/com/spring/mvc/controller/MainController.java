package com.spring.mvc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.mvc.model.IIT;
import com.spring.mvc.service.IISCService;

@Controller
public class MainController

{
	@Autowired
	IISCService iis;
	
	@RequestMapping(value="/Homepage")
	public String showHome()
	{
		String view="Homepage";
		return view;
	}
	@RequestMapping(value="/showall")
	public String sAll(Model model,HttpServletRequest request)
	{
		List<IIT>list=iis.all();
		ServletContext context=request.getServletContext();
		context.setAttribute("iit",list);
		String view="display";
		return view;
		
	}
	

}
