package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.IIT;

public interface IISCService
{
	List<IIT>all();

}
