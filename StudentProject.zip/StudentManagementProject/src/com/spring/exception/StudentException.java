package com.spring.exception;

public class StudentException extends Exception
{

	public StudentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
