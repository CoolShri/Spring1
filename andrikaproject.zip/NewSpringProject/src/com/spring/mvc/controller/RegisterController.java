package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.spring.mvc.exception.myException;
import com.spring.mvc.model.Customer;
import com.spring.mvc.service.ICustomerService;

@Controller
public class RegisterController {
	
	@Autowired
	ICustomerService custSer;
	
	@RequestMapping("/Home")
	public String showHomePage()
	{
		String view="HomePage";
		return view;
	}
	
	@RequestMapping("/register")
	public String registrationPage(Model model, HttpServletRequest request)
	{
		String view="registerPage";
		model.addAttribute("msg", "Welcome To Registration Page");
		model.addAttribute("customer", new Customer());
		List<String> list=new ArrayList<>();
		list.add("male");
		list.add("female");
		ServletContext context=request.getServletContext();
		context.setAttribute("genderList",list);
		return view;
		
	}
	
	@RequestMapping(value="/registerPage" ,method=RequestMethod.POST)
	public String validateRegistrationPage(@Valid @ModelAttribute("customer") Customer cust, BindingResult result, Model model, HttpServletRequest req)
	{
		String view="";
		if(result.hasErrors())
		{
			view="registerPage";
			return view;
		}
		else
		{
			custSer.insertCustomer(cust);
			ServletContext context=req.getServletContext();
			context.setAttribute("customer", cust);
			view="successPage";
			return view;
		}
	}
	
	@RequestMapping(value="/search")
	public String searchCustomer(Model model, HttpServletRequest request)
	{
		model.addAttribute("customer", new Customer());
		String view="searchPage";
		model.addAttribute("msg", "Welcome to Search Page");
		return view;
		
	}
	
	@RequestMapping(value="/searchMyPage" ,method=RequestMethod.POST)
	public String searchCustomerById(@Valid @ModelAttribute("customer") Customer cust, BindingResult result, Model model, HttpServletRequest req) throws myException
	{
		Customer custom=custSer.searchById(cust.getcId());
		if(custom!=null)
		{
			model.addAttribute("customer", new Customer());
			String view="showCustomerData";
			ServletContext context=req.getServletContext();
			context.setAttribute("custom", custom);
			model.addAttribute("MyMessage", "Your Data..");
			return view;
		}
		else
		{
			throw new myException("Sorry No Id found!!");
		}
		
	}
	@RequestMapping(value="/display")
	public String displayAll(Model model, HttpServletRequest req) throws myException
	{
		String view="";
		List<Customer> list=custSer.displayAllCustomer();
		if(list!=null)
		{
			model.addAttribute("listCus", list);
			view="DisplayPage";
		}
		else
		  {
			  throw new myException("display is not correct");
			  
		  }
		return view;
		
	}

}
