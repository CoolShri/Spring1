package com.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.mvc.dao.ICustomerDao;
import com.spring.mvc.model.Customer;

@Service
@Transactional

public class CustomerService implements ICustomerService {
	
	@Autowired
	ICustomerDao custDao;

	@Override
	public void insertCustomer(Customer cust) {
		// TODO Auto-generated method stub
		custDao.insertCustomer(cust);
	}

	@Override
	public Customer searchById(int id) {
		// TODO Auto-generated method stub
		return custDao.searchById(id);
	}

	@Override
	public List<Customer> displayAllCustomer() {
		// TODO Auto-generated method stub
		return custDao.displayAllCustomer();
	}

}
