package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.Customer;

public interface ICustomerService {
	
	public void insertCustomer(Customer cust);
	public Customer searchById(int id);
	public List<Customer> displayAllCustomer();

}
