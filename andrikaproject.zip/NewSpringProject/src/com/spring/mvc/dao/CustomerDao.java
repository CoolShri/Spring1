package com.spring.mvc.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.Customer;

@Repository
public class CustomerDao implements ICustomerDao{
	
	@PersistenceContext
	EntityManager manager;

	@Override
	public void insertCustomer(Customer cust) {
		// TODO Auto-generated method stub
		manager.persist(cust);
		
	}

	@Override
	public Customer searchById(int id) {
		// TODO Auto-generated method stub
		return manager.find(Customer.class, id);
	}
	
	public List<Customer> displayAllCustomer()
	{
		Query query = manager.createQuery("select cus from Customer cus");
		List<Customer> list = query.getResultList();
		return list;
		
	}

}
