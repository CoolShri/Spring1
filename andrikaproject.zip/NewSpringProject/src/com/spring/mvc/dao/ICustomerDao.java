package com.spring.mvc.dao;

import java.util.List;

import com.spring.mvc.model.Customer;

public interface ICustomerDao {
	
	public void insertCustomer(Customer cust);
	public Customer searchById(int id);
	public List<Customer> displayAllCustomer();
}
