package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cId;
	
	@NotEmpty(message="first name cannot be empty")
	
	private String fname;
	
	@NotEmpty(message="last name cannot be empty")
	
	private String lname;
	
	@NotNull(message="this field cannot be empty")
	@Min(value=20)
	private int age;
	
	@NotEmpty(message="please select a gender")
	private String gender;
	
	@NotEmpty(message="this field cannot be empty")
	
	private String phNum;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String fname, String lname, int age, String gender, String phNum) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		this.gender = gender;
		this.phNum = phNum;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhNum() {
		return phNum;
	}
	public void setPhNum(String phNum) {
		this.phNum = phNum;
	}
	
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", lname=" + lname + ", age=" + age + ", gender=" + gender + ", phNum="
				+ phNum + "]";
	}
	

}
