package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.transform.impl.AddDelegateTransformer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.mvc.model.Employee;
import com.spring.mvc.service.IEmployeeService;

@Controller
public class Controler 
{

	@Autowired
	IEmployeeService empSer;
	
	@RequestMapping("/Homepage")
	public String showHomePage()
	{
		String view="Homepage";
		return view;
	}

	@RequestMapping("/MyregisterPage")
	
		public String showRegister(Model model,HttpServletRequest request)
		{

		model.addAttribute("msg","Welcome To Registration Page");
		model.addAttribute("employee",new Employee());		
		String view="Register";
		List<String>list=new ArrayList<>();
		list.add("Ghaziabad");
		list.add("Lucknow");
		list.add("Mumbai");
		list.add("Pune");
		list.add("Chennai");
		ServletContext context=request.getServletContext();
		context.setAttribute("city",list);
		List<String>list1=new ArrayList<>();
		list1.add("male");
		list1.add("female");
		list1.add("transgender");
		ServletContext context1=request.getServletContext();
		context.setAttribute("numberlist",list);
		return view;
		}
	@RequestMapping(value="/Register",method=RequestMethod.POST)
	public String validation(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
		if(bindingResult.hasErrors())
		{
			view="Register";
			return view;
			
		}
		else
		{
			empSer.insertEmployee(emp);
			ServletContext context1=req.getServletContext();
			context1.setAttribute("employee",emp);
			return view;
			
		}
	}
	
	
}
