package com.spring.mvc.service;

import com.spring.mvc.model.Employee;

public interface IEmployeeService {
	void insertEmployee(Employee emp);

}
