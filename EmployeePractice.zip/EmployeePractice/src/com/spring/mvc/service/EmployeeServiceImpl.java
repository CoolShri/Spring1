package com.spring.mvc.service;



import org.springframework.beans.factory.annotation.Autowired;

import com.spring.mvc.dao.IEmployeeDao;
import com.spring.mvc.model.Employee;

public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	IEmployeeDao empDao;

	@Override
	public void insertEmployee(Employee emp) 
	{
		empDao.insertEmployee(emp);
	}

}
