package com.spring.mvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.Employee;
@Repository
public class EmployeeDaoImpl implements IEmployeeDao 

{
	

    @PersistenceContext
	private EntityManager manager;
	

	@Override
	public void insertEmployee(Employee emp) 
	{
		
		manager.persist(emp);
	}

}
