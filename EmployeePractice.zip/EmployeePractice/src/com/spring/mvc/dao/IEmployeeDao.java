package com.spring.mvc.dao;

import com.spring.mvc.model.Employee;

public interface IEmployeeDao
{
	void insertEmployee(Employee emp);
	

}
