package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee 
{


	public Employee()
	{
		super();
	}
	/*private String name;
	private String designation;
	private String gender;
	private double salary;
	private String city;*/
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
int empId;
	@NotEmpty(message="Name can not be empty")
	@Size(min=3,max=10,message="Name should be in limits")
String name;
	@NotEmpty(message="Designation can not be empty")
	String companyName;
String designation;
	@NotEmpty(message="Salary can not be empty")
String salary;
	@NotEmpty(message="Please select the city")
String  city;
	@NotEmpty(message="Please select the gender")
String gender;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Employee(int empId, String name, String designation, String gender, String city) {
		super();
		this.empId = empId;
		this.name = name;
		this.designation = designation;
		this.gender = gender;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", designation=" + designation + ", gender=" + gender
				+", city=" + city + "]";
	}
	
}
