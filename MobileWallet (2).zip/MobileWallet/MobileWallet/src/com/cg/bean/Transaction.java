package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int Transaction;
	int senderAcc;
	int ReceiverAcc;
	String Date;
	int amt;
	
	public Transaction() {
		
	}
	
	public int getSenderAcc() {
		return senderAcc;
	}
	public void setSenderAcc(int senderAcc) {
		this.senderAcc = senderAcc;
	}
	public int getReceiverAcc() {
		return ReceiverAcc;
	}
	public void setReceiverAcc(int receiverAcc) {
		ReceiverAcc = receiverAcc;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public int getAmt() {
		return amt;
	}
	public void setAmt(int amt) {
		this.amt = amt;
	}
	public Transaction(int senderAcc, int receiverAcc, String date, int amt) {
		super();
	
		this.senderAcc = senderAcc;
		ReceiverAcc = receiverAcc;
		Date = date;
		this.amt = amt;
	}
	@Override
	public String toString() {
		return "Transaction [ senderAcc=" + senderAcc + ", ReceiverAcc=" + ReceiverAcc
				+ ", Date=" + Date + ", amt=" + amt + "]";
	}
	
}
