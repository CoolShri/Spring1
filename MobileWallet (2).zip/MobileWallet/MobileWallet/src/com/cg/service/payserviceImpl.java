package com.cg.service;

import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.dao.paymentImpl;

public class payserviceImpl implements payservice {
 paymentImpl paydao=new paymentImpl();
	@Override
	public int createAccount(Customer cust,Account acc) {
		
		return paydao.createAccount(cust,acc);
	}
	@Override
	public int show_balance(int accno) {
		
		return paydao.show_balance(accno);
	}
	
	public int updateBalance(int acc,int bal) {
		return paydao.updateBalance(acc,bal);
	
	}
	
	public int withdraw(int accno,int bal)
	{
		return paydao.withdraw(accno, bal);
		
	}
	public int fundTransfer(int myacc, int depacc, int bal) {
		
		return paydao.fundTransfer(myacc, depacc, bal);
	}
	public  void Print_Transaction(int amt)
	{
		paydao.Print_Transaction(amt);
	}
	}
	

