package com.spring.mvc.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.mvc.bean.Employee;

@Controller
public class ControllerPage 
{

	@RequestMapping("/")
	public String blankPage()
	{
		String view="HomePage";
		return view;
	}
	@RequestMapping(value="/log", method=RequestMethod.GET)
	public String loginpage(Model model)
	{
		String view="LoginPage";
		model.addAttribute("msg","Welcome To Login Page");
		return view;
	}
	@RequestMapping(value="/log", method=RequestMethod.POST)
	public String validatelogin(@RequestParam("username") String user,@RequestParam("pwd") String pass,Model model)
	{
		String view="";
		if("admin".equalsIgnoreCase(user) && "admin".equalsIgnoreCase(pass))
		{
			view="Success";
			model.addAttribute("msg","Successfully Login "+user);
			
		}
		else
		{
			view="failure";
			model.addAttribute("msg","Login Failed");
		
		}
		return view;
	}
	@RequestMapping(value="/reg", method=RequestMethod.GET)
	public String regpage(Model model)
	{
		String view="Register";
		model.addAttribute("msg","Welcome To Registration Page");
		return view;
	}
	@RequestMapping(value="/reg", method=RequestMethod.POST)
	public String validateReg(@RequestParam Map<String,String> map1, Model model)
	{
		String view="";
		Employee e=new Employee();
		e.setFname(map1.get("fname"));
		e.setLname(map1.get("lname"));
		e.setGender(map1.get("gender"));
		e.setCity(map1.get("city"));
		if(e!=null)
		{
			view="showdata";
			model.addAttribute("emp",e);
		
		}
		else
		{
			view="noshowdata";
			model.addAttribute("msg","Registration failed");
			
		}
		return view;
	}
	
}
