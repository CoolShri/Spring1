package com.spring.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.dao.EmployeeDao;
import com.spring.mvc.dao.IEmployeeDao;
import com.spring.mvc.model.Employee;
@Service
@Transactional
public class EmployeeService implements IEmployeeService{
	@Autowired
   IEmployeeDao empDao;
	
	@Override
	public void insertEmployee(Employee emp) {
		empDao.insertEmployee(emp);
		
	}

	@Override
	public List<Employee> getAllEmployees(int id) {
	return empDao.getAllEmployees(id);
	}

}
