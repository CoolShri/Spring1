package com.cg.mvc.service;

import java.util.List;

import com.cg.mvc.model.Book;

public interface IBookService
{
	void insertBook(Book book);
	List <Book> getAllBooks();

}
