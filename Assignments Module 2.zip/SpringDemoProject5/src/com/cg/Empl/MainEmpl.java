package com.cg.Empl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class MainEmpl {
public static void main(String[] args) {
	
	Department d=new Department();
	@SuppressWarnings("resource")
	
	ApplicationContext con=new ClassPathXmlApplicationContext("config.xml");
	List<Employee> al=new ArrayList<Employee>();
	Department D= con.getBean(Department.class);
	Employee E= con.getBean(Employee.class);
	
	E.setEmpid(101);
	E.setEmpName("Aakarsh");
	E.setDept(D);
	al.add(E);
	D.setEmps(al);
	
	
	Employee E1= con.getBean(Employee.class);
	
	E1.setEmpid(102);
	E1.setEmpName("Sanjana");
	d.setDeptName("L&D");
	E1.setDept(d);
	al.add(E1);
	D.setEmps(al);
	D.DisplayDetails();
	
	
	
	
}
}
