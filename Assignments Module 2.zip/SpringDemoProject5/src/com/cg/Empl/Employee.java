package com.cg.Empl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Scope("prototype")
public class Employee {
	private int empid;
	private String empName;
	@Autowired
	private Department dept;

	public int getEmpid() {
		return empid;
	}

	public String getEmpName() {
		return empName;
	}

	public Department getDept() {
		return dept;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Autowired
	public void setDept(Department dept) {
		this.dept = dept;
	}
	
	public String getDName(){
		return dept.getDeptName();
	}
 	
}
