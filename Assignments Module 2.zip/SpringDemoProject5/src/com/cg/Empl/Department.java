package com.cg.Empl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class Department {
	@Value("HR")
	private String deptName;
	@Autowired
	List<Employee> emps;
	public List<Employee> getEmps() {
		return emps;
	}
	@Autowired
	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public void DisplayDetails(){
		for(Employee e:emps){
			System.out.print(" "+e.getEmpid());
			System.out.print(" "+e.getEmpName());
			System.out.print(" "+e.getDName());
			
			System.out.println(" ");
		}
	}
}
