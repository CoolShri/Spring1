package com.cg.emp;

public class Department {
	private String deptName;

	
	public String getDeptName() {
		return deptName;
	}


	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}


	
	
}
