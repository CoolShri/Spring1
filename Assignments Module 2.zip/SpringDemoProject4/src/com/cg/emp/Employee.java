package com.cg.emp;

public class Employee {
	private int empid;
	private String empName;
	private Department dept;

	public int getEmpid() {
		return empid;
	}

	public String getEmpName() {
		return empName;
	}

	public Department getDept() {
		return dept;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public String getDName(){
		return dept.getDeptName();
	}
 	
}
