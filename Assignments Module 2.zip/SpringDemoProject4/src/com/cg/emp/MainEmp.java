package com.cg.emp;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

@SuppressWarnings("deprecation")
public class MainEmp {

	public static void main(String[] args) {
	XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("config.xml"));
	Employee E=(Employee) factory.getBean("emp");
	System.out.println("Employee id is "+E.getEmpid());
	System.out.println("Employee name is "+E.getEmpName());
	System.out.println("Department name is "+E.getDName());

	}

}
