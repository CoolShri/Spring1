package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class Dbutil {
public static Connection getCon(){
	Connection con=null;
	Context ctx=null;
	DataSource ds=null;
	try {
		 ctx=new InitialContext();
		 ds=(DataSource)ctx.lookup("java:/jdbc/OracleDS");
		con=ds.getConnection();
	} catch (NamingException e) {
		
		e.printStackTrace();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	return con;
	

}
}
