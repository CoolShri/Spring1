

public class Employee {

@Override
public String toString() {
	return "Employee [name=" + name + ", designation=" + designation + ", salary=" + salary + ", city=" + city
			+ ", gender=" + gender + "]";
}
public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
String name;
String designation;
String salary;
String  city;
String gender;
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(String name, String designation, String salary, String city, String gender) {
	super();
	this.name = name;
	this.designation = designation;
	this.salary = salary;
	this.city = city;
	this.gender = gender;
}
}