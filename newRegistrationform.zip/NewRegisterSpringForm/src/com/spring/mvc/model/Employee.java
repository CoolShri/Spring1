package com.spring.mvc.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Employee {

@Override
public String toString() {
	return "Employee [name=" + name + ", designation=" + designation + ", salary=" + salary + ", city=" + city
			+ ", gender=" + gender + "]";
}
public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@NotEmpty(message="Name can not be empty")
	@Size(min=3,max=10,message="Name should be in limits")
String name;
	@NotEmpty(message="Designation can not be empty")
String designation;
	@NotEmpty(message="Salary can not be empty")
String salary;
	@NotEmpty(message="Please select the city")
String  city;
	@NotEmpty(message="Please select the gender")
String gender;
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(String name, String designation, String salary, String city, String gender) {
	super();
	this.name = name;
	this.designation = designation;
	this.salary = salary;
	this.city = city;
	this.gender = gender;
}
}