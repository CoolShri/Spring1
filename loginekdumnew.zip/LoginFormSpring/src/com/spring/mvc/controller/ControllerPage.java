package com.spring.mvc.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControllerPage 
{

	@RequestMapping("/")
	public String blankPage()
	{
		String view="HomePage";
		return view;
	}
	@RequestMapping("/log")
	public String loginpage(Model model)
	{
		String view="LoginPage";
		model.addAttribute("msg","Welcome To Login Page");
		return view;
	}
	@RequestMapping(value="/log", method=RequestMethod.POST)
	public String validatelogin(@RequestParam("username") String user,@RequestParam("pwd") String pass,Model model)
	{
		String view=null;
		if("admin".equalsIgnoreCase(user) && "admin".equalsIgnoreCase(pass))
		{
			view="Success";
			model.addAttribute("msg","Successfully Login"+user);
		}
		else
		{
		view="failure";
		model.addAttribute("msg","Login Failed");
		}
		return view;
	}
	@RequestMapping("/reg")
	public String registrationPage(Model model)
	{
		String view="registerPage";
		model.addAttribute("msg","Welcome To Registration Page");
		return view;
	}
	@RequestMapping(value="/reg",method=RequestMethod.POST)
	public String validateregistrationPage(@RequestParam Map<String,String> map,Model model)
	{
		Employee emp=new Employee();
		emp.setFirstName(map.get("usr"));
		emp.setLastName(map.get("lusr"));
		emp.setGender(map.get("gender"));
		emp.setCity(map.get("city"));
		if(emp!=null)
		{
			String view="showData";
					model.addAttribute("employee",emp);
			return view;
		}
		else
		{
			String view="notShowData";
			model.addAttribute("message","No Data To Show");
			return view;
		}
	}
	
	
}
