package com.cg.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.mvc.model.Book;
@Repository
public class BookDaoImpl implements IBookDao {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void insertBook(Book book) {
		manager.persist(book);
		
	}

	@Override
	public List<Book> getAllBooks() {
		Query query=manager.createQuery("select b from Book b");
		List<Book> list=query.getResultList();
		return list;
	}

}
