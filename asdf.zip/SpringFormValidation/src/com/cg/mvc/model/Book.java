package com.cg.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="book_master")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@NotEmpty(message = "name should not be empty")
    @Size(min=3,max=10,message="Book name must contain min 3 characters & max 10 characters)")
	private String name;

	@NotEmpty(message = "author should not be empty")
	private String author;

	@NotNull(message = "cost should not be empty")
	@Min(message="Minimum cost is 100", value=100)
	@Max(message="Maximum cost is 1000", value=1000)
	private Double cost;

	@NotEmpty(message = "category should not be empty")
	private String category;

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
